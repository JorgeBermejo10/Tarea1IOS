//
//  ViewController.swift
//  Tarea1IOS
//
//  Created by user211910 on 18/10/2023.
//

import UIKit
import Foundation

class ViewController: UIViewController {

        
    
    @IBOutlet weak var imagen: UIImageView!
    var numeros: [Int] = []
    var timer:Timer = Timer()
    var orden:[Int] = [0,1,2,3]
    var x = 0
    let arrayfotos: [UIImage]=[UIImage(named: "villareal")!,UIImage(named: "bilbao")!,UIImage(named: "sevilla")!,UIImage(named: "atleti")!]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        timer = Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(mostrarFotos), userInfo: nil, repeats: true)
        orden.shuffle()
    }
    @IBOutlet var botones: [UIButton]!

    @IBAction func Pasarbotones(sender:UIButton!){
        
        for i in 0..<botones.count{
            if sender==botones[i]{
            numeros.append(i)
            print(numeros)
            }
        }
        if numeros.count == 4 {
            puntuacion()
            performSegue(withIdentifier: "vistapuntuacion", sender: nil)
        }
    }
    
    
    @objc func mostrarFotos()  {
        
        if x==arrayfotos.count {
            timer.invalidate()
        } else {
            imagen.image = arrayfotos[orden[x]]
            x+=1
        }
        
    }
    
    func puntuacion(){
        
        var final = 0
        for i in 0..<orden.count {
            if orden[i] == numeros[i]{
                final += 1
            }
        }
        
        UserDefaults.standard.setValue(final, forKey: "Puntuacion")
    }

}
