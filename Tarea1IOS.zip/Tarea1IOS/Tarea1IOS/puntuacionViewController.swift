
import UIKit
import Foundation

class puntuacionViewController: UIViewController {

    var puntuacion : Int = UserDefaults.standard.integer(forKey: "Puntuacion")
    var nombreusuario : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        nuneroPuntuacion.text = String(puntuacion)
    }
    
    @IBOutlet weak var nombrePuntuacion: UITextField!
    @IBOutlet weak var nuneroPuntuacion: UITextField!

    
    @IBAction func botonpuntuacionpulsado(_ sender: Any) {
        nombreusuario=nombrePuntuacion.text!
    }
    
    func guardarPartida() {
        
    }
}
